/* 
 * File:   main.cpp
 * Author: Dustin Badillo
 * Created on February 17, 2016, 9:45 AM
 * Purpose: Our first program
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants no in-constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables no doubles
    
    //Initialize variables
    
    //Input values
    
    //Map the input to the outputs
    
    //Output the results
    cout<<"Hello World"<<endl;
    
    //Exit Stage Right!
    return 0;
}

